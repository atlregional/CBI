"""
Arterial Intersection Congestion Severity — steps 1-5.

Methodology (as specified):
  1. System-wide average speed by hour of day.
  2. Arterial-only average speed by hour of day (f_system IN ARTERIAL_F_SYSTEM).
  3. Free-flow hour(s) = the hour(s) with the HIGHEST average speed in the
     arterial-wide curve from step 2 — identified once, system-wide, then
     applied per-segment as that segment's own free-flow baseline. This is
     deliberately NOT computed per-segment-independently: a chronically
     congested segment could otherwise define its own artificially-low
     "free flow" hour and never register as abnormal — the exact failure
     mode documented in this project's Known Limitations section (McDonough
     US-23/GA-42 case).
  4. AADT per segment, with named-arterial path integration so fragmented
     corridors (Buford Hwy, Roswell Rd, etc. — see sql/001) roll up
     correctly instead of scattering across dozens of disconnected segments.
  5. K-means clustering on [peak-hour speed drop, occurrence, AADT]
     (standardized) to identify the worst-behaving cluster, then rank within
     it for the top 20.

Output: a new table, arterial_intersection_severity, plus a DataFrame
returned for use by the standalone HTML page generator (Section 6).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import polars as pl
import psycopg
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

import cbi_database

# ---- Config — review before running -----------------------------------
ARTERIAL_F_SYSTEM = (3, 4)      # FHWA: 3=Principal Arterial, 4=Minor Arterial
CONGESTION_RATIO = 0.70          # consistent with the rest of the pipeline
FREE_FLOW_TOP_N_HOURS = 1        # widen to e.g. 3 for a more stable baseline
AM_PEAK_HOURS = (7, 8, 9)
PM_PEAK_HOURS = (16, 17, 18)
KMEANS_K = 6                     # tune based on elbow/silhouette if needed
TOP_N = 20
MIN_ANALYZED_DAYS = 30           # segments with less data than this are excluded
# -------------------------------------------------------------------------


@dataclass(frozen=True)
class FreeFlowResult:
    free_flow_hours: list[int]
    arterial_hourly_curve: pl.DataFrame


def compute_system_wide_hourly_speed(connection: psycopg.Connection) -> pl.DataFrame:
    """Step 1: average speed by hour of day, all roads."""
    query = """
        SELECT
            EXTRACT(HOUR FROM measurement_tstamp)::integer AS hr,
            AVG(speed) AS avg_speed_system
        FROM "Year_2025".probe_readings
        WHERE speed IS NOT NULL
        GROUP BY hr
        ORDER BY hr
    """
    return pl.read_database_uri(
        query=query, uri=cbi_database.database_uri(), engine="connectorx"
    )


def compute_arterial_hourly_speed(connection: psycopg.Connection) -> pl.DataFrame:
    """Step 2: average speed by hour of day, Arterials only."""
    f_system_list = ",".join(str(v) for v in ARTERIAL_F_SYSTEM)
    query = f"""
        SELECT
            EXTRACT(HOUR FROM r.measurement_tstamp)::integer AS hr,
            AVG(r.speed) AS avg_speed_arterial
        FROM "Year_2025".probe_readings AS r
        JOIN tmc_metadata AS m ON m.tmc = r.tmc_code
        WHERE r.speed IS NOT NULL
          AND m.f_system IN ({f_system_list})
        GROUP BY hr
        ORDER BY hr
    """
    return pl.read_database_uri(
        query=query, uri=cbi_database.database_uri(), engine="connectorx"
    )


def identify_free_flow_hours(
    arterial_hourly: pl.DataFrame, top_n: int = FREE_FLOW_TOP_N_HOURS
) -> FreeFlowResult:
    """
    Step 3 (part 1): the hour(s) with the highest arterial-wide average
    speed, identified once from the system/arterial aggregate — not
    per-segment. This single reference point gets applied to every segment
    individually in compute_segment_drop_ratios().
    """
    ranked = arterial_hourly.sort("avg_speed_arterial", descending=True)
    free_flow_hours = ranked.head(top_n)["hr"].to_list()
    return FreeFlowResult(free_flow_hours=free_flow_hours, arterial_hourly_curve=arterial_hourly)


def compute_segment_hourly_speed(connection: psycopg.Connection) -> pl.DataFrame:
    """Per-segment average speed by hour, Arterials only. Feeds step 3 (part 2)."""
    f_system_list = ",".join(str(v) for v in ARTERIAL_F_SYSTEM)
    query = f"""
        SELECT
            r.tmc_code,
            m.road,
            m.intersection,
            m.county,
            m.aadt,
            EXTRACT(HOUR FROM r.measurement_tstamp)::integer AS hr,
            AVG(r.speed) AS avg_speed,
            COUNT(*) AS n_obs
        FROM "Year_2025".probe_readings AS r
        JOIN tmc_metadata AS m ON m.tmc = r.tmc_code
        WHERE r.speed IS NOT NULL
          AND m.f_system IN ({f_system_list})
        GROUP BY r.tmc_code, m.road, m.intersection, m.county, m.aadt, hr
    """
    return pl.read_database_uri(
        query=query, uri=cbi_database.database_uri(), engine="connectorx"
    )


def compute_segment_drop_ratios(segment_hourly: pl.DataFrame, free_flow: FreeFlowResult) -> pl.DataFrame:
    """
    Step 3 (part 2): apply the system-identified free-flow hour(s) to each
    segment's own speed at those hours to get a per-segment free-flow
    baseline, then compute that segment's speed-drop ratio during AM/PM
    peak hours against its own free-flow baseline.
    """
    free_flow_speed_per_segment = (
        segment_hourly
        .filter(pl.col("hr").is_in(free_flow.free_flow_hours))
        .group_by("tmc_code")
        .agg(pl.col("avg_speed").mean().alias("free_flow_speed"))
    )

    peak_hours = list(AM_PEAK_HOURS) + list(PM_PEAK_HOURS)

    peak_speed_per_segment = (
        segment_hourly
        .filter(pl.col("hr").is_in(peak_hours))
        .group_by(["tmc_code", "road", "intersection", "county", "aadt"])
        .agg(pl.col("avg_speed").min().alias("peak_worst_speed"))
    )

    joined = peak_speed_per_segment.join(
        free_flow_speed_per_segment, on="tmc_code", how="inner"
    )

    return joined.with_columns(
        (pl.col("peak_worst_speed") / pl.col("free_flow_speed")).alias("peak_drop_ratio")
    ).filter(
        pl.col("free_flow_speed") > 0
    )


def attach_occurrence(connection: psycopg.Connection, segments: pl.DataFrame) -> pl.DataFrame:
    """
    Occurrence: percentage of analyzed weekdays this segment's peak-hour
    average speed fell below CONGESTION_RATIO of its own free-flow baseline
    (from compute_segment_drop_ratios). Consistent in spirit with the
    occurrence definition used throughout the rest of this project
    (Appendix A.4), applied here at the hourly-aggregate level rather than
    the 5-minute-interval level.
    """
    tmc_list = segments["tmc_code"].to_list()
    if not tmc_list:
        return segments.with_columns(pl.lit(0.0).alias("occurrence_pct"))

    tmc_in = ",".join(f"'{t}'" for t in tmc_list)
    peak_hours = list(AM_PEAK_HOURS) + list(PM_PEAK_HOURS)
    peak_hours_in = ",".join(str(h) for h in peak_hours)

    query = f"""
        SELECT
            r.tmc_code,
            r.measurement_tstamp::date AS analysis_date,
            MIN(r.speed) AS min_peak_speed,
            COUNT(*) AS n_obs
        FROM "Year_2025".probe_readings AS r
        WHERE r.tmc_code IN ({tmc_in})
          AND EXTRACT(HOUR FROM r.measurement_tstamp)::integer IN ({peak_hours_in})
          AND r.speed IS NOT NULL
        GROUP BY r.tmc_code, r.measurement_tstamp::date
    """
    daily = pl.read_database_uri(
        query=query, uri=cbi_database.database_uri(), engine="connectorx"
    )

    free_flow_lookup = segments.select(["tmc_code", "free_flow_speed"])
    daily = daily.join(free_flow_lookup, on="tmc_code", how="inner").with_columns(
        (pl.col("min_peak_speed") < CONGESTION_RATIO * pl.col("free_flow_speed")).alias("is_congested_day")
    )

    occurrence = (
        daily.group_by("tmc_code")
        .agg(
            pl.col("analysis_date").n_unique().alias("analyzed_days"),
            pl.col("is_congested_day").sum().alias("congested_days"),
        )
        .filter(pl.col("analyzed_days") >= MIN_ANALYZED_DAYS)
        .with_columns(
            (100.0 * pl.col("congested_days") / pl.col("analyzed_days")).alias("occurrence_pct")
        )
    )

    return segments.join(
        occurrence.select(["tmc_code", "analyzed_days", "occurrence_pct"]),
        on="tmc_code",
        how="inner",
    )


def attach_named_arterial_groups(connection: psycopg.Connection, segments: pl.DataFrame) -> pl.DataFrame:
    """
    Step 4: tag each segment with its named-arterial group where one
    exists (Section sql/001_named_arterial_registry.sql). Segments that
    don't match any curated pattern keep their own road/intersection as
    their group — they are analyzed individually, not dropped.
    """
    aliases_query = """
        SELECT a.arterial_name, al.road_pattern
        FROM "Year_2025".named_arterial_road_aliases al
        JOIN "Year_2025".named_arterials a ON a.arterial_id = al.arterial_id
    """
    aliases = pl.read_database_uri(
        query=aliases_query, uri=cbi_database.database_uri(), engine="connectorx"
    )

    def find_group(road: str) -> str:
        if road is None:
            return "UNKNOWN"
        road_upper = road.upper()
        for pattern, name in zip(aliases["road_pattern"].to_list(), aliases["arterial_name"].to_list()):
            if pattern.upper() in road_upper:
                return name
        return road  # no curated match — treat its own road name as its group

    groups = [find_group(r) for r in segments["road"].to_list()]
    return segments.with_columns(pl.Series("arterial_group", groups))


def aggregate_to_intersection_level(segments: pl.DataFrame) -> pl.DataFrame:
    """
    Collapse to one row per (arterial_group, intersection) — the unit the
    clustering step operates on. Named-arterial groups aggregate all their
    matched segments together, which is what fixes the fragmentation
    problem for roads like Buford Hwy; ungrouped segments pass through as
    their own single-row group.
    """
    return (
        segments.group_by(["arterial_group", "intersection", "county"])
        .agg(
            pl.col("peak_drop_ratio").min().alias("worst_peak_drop_ratio"),
            pl.col("occurrence_pct").max().alias("occurrence_pct"),
            pl.col("aadt").max().alias("aadt"),
            pl.col("tmc_code").n_unique().alias("segment_count"),
        )
        .filter(pl.col("aadt").is_not_null() & (pl.col("aadt") > 0))
    )


def run_kmeans_ranking(intersections: pl.DataFrame, k: int = KMEANS_K, top_n: int = TOP_N) -> pl.DataFrame:
    """
    Step 5: K-means on standardized [drop_ratio, occurrence, AADT], then
    rank within the worst-behaving cluster to produce the top N.

    K-means finds groups, not a ranking — the extra ranking step is
    necessary regardless of k. "Worst" cluster is chosen by whichever
    cluster centroid has the lowest drop_ratio combined with the highest
    occurrence and AADT (all three, standardized, summed with drop_ratio
    sign-flipped since lower is worse there).
    """
    features = intersections.select(
        ["worst_peak_drop_ratio", "occurrence_pct", "aadt"]
    ).to_numpy()

    scaler = StandardScaler()
    scaled = scaler.fit_transform(features)

    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = model.fit_predict(scaled)

    intersections = intersections.with_columns(pl.Series("cluster", labels))

    # Identify the worst cluster: for each cluster centroid (in standardized
    # space), score = -drop_ratio_z + occurrence_z + aadt_z (higher = worse).
    centroids = model.cluster_centers_
    cluster_scores = -centroids[:, 0] + centroids[:, 1] + centroids[:, 2]
    worst_cluster = int(np.argmax(cluster_scores))

    worst_cluster_rows = intersections.filter(pl.col("cluster") == worst_cluster)

    # Rank within the worst cluster by the same composite direction.
    worst_features = worst_cluster_rows.select(
        ["worst_peak_drop_ratio", "occurrence_pct", "aadt"]
    ).to_numpy()
    worst_scaled = scaler.transform(worst_features)
    composite = -worst_scaled[:, 0] + worst_scaled[:, 1] + worst_scaled[:, 2]

    ranked = worst_cluster_rows.with_columns(
        pl.Series("composite_score", composite)
    ).sort("composite_score", descending=True)

    return ranked.head(top_n).with_row_index("rank", offset=1)


def save_results(connection: psycopg.Connection, ranked: pl.DataFrame) -> None:
    with connection.cursor() as cursor:
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS "Year_2025".arterial_intersection_severity (
                rank integer,
                arterial_group text,
                intersection text,
                county text,
                worst_peak_drop_ratio double precision,
                occurrence_pct double precision,
                aadt integer,
                segment_count integer,
                composite_score double precision,
                computed_at timestamptz DEFAULT now()
            )
            """
        )
        cursor.execute('TRUNCATE TABLE "Year_2025".arterial_intersection_severity')

        rows = [
            (
                int(row["rank"]), row["arterial_group"], row["intersection"],
                row["county"], float(row["worst_peak_drop_ratio"]),
                float(row["occurrence_pct"]), int(row["aadt"]),
                int(row["segment_count"]), float(row["composite_score"]),
            )
            for row in ranked.iter_rows(named=True)
        ]

        cursor.executemany(
            """
            INSERT INTO "Year_2025".arterial_intersection_severity (
                rank, arterial_group, intersection, county,
                worst_peak_drop_ratio, occurrence_pct, aadt,
                segment_count, composite_score
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            rows,
        )
    connection.commit()


def run_analysis(connection: psycopg.Connection) -> pl.DataFrame:
    print("Step 1: system-wide hourly speed...")
    system_hourly = compute_system_wide_hourly_speed(connection)

    print("Step 2: arterial-wide hourly speed...")
    arterial_hourly = compute_arterial_hourly_speed(connection)

    print("Step 3a: identifying free-flow hour(s)...")
    free_flow = identify_free_flow_hours(arterial_hourly)
    print(f"  Free-flow hour(s): {free_flow.free_flow_hours}")

    print("Step 3b: per-segment hourly speed...")
    segment_hourly = compute_segment_hourly_speed(connection)

    print("Step 3c: per-segment peak-hour drop ratios...")
    segments = compute_segment_drop_ratios(segment_hourly, free_flow)

    print("Attaching occurrence...")
    segments = attach_occurrence(connection, segments)

    print("Step 4: attaching named-arterial groups...")
    segments = attach_named_arterial_groups(connection, segments)

    print("Aggregating to intersection level...")
    intersections = aggregate_to_intersection_level(segments)
    print(f"  {intersections.height} candidate intersections")

    print("Step 5: K-means clustering and ranking...")
    ranked = run_kmeans_ranking(intersections)

    print("Saving results...")
    save_results(connection, ranked)

    print(f"\nTop {TOP_N} arterial intersections by composite severity:")
    print(ranked.select(["rank", "arterial_group", "intersection", "county", "worst_peak_drop_ratio", "occurrence_pct", "aadt"]))

    return ranked


if __name__ == "__main__":
    with psycopg.connect(**cbi_database.connection_kwargs()) as conn:
        run_analysis(conn)
