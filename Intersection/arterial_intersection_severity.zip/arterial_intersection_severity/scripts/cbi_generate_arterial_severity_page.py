"""
Generates a standalone HTML page for the Top 20 Arterial Intersections by
Congestion Severity — Section 6 of the methodology ("new standalone page,
combine into main CBI dashboard later").

Reads from "Year_2025".arterial_intersection_severity (populated by
cbi_arterial_intersection_severity.py) and produces a single self-contained
HTML file: KPI summary, a ranked table, and a scatter plot of AADT vs.
peak-hour speed drop, colored by occurrence — matching the navy/amber
visual language already established across this project's other outputs
(technical report, corridor reports).

Merging into the main CBI dashboard later: the existing regional dashboard
(regional_congestion_report_*.html) already uses a tabbed layout — the
cleanest integration path is adding a fifth/sixth tab that embeds this same
table + chart, reading from this same arterial_intersection_severity table.
This script is intentionally self-contained so it can run standalone first.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path

import plotly.graph_objects as go
import plotly.io as pio
import polars as pl
import psycopg

import cbi_database

NAVY = "#1F3864"
ACCENT = "#2E5395"
AMBER = "#B8860B"
LIGHT_SHADE = "#DCE6F1"

OUTPUT_PATH = Path(r"C:\Users\Soheil\Desktop\CBI\outputs\arterial_intersection_severity.html")


def load_results(connection: psycopg.Connection) -> pl.DataFrame:
    query = """
        SELECT rank, arterial_group, intersection, county,
               worst_peak_drop_ratio, occurrence_pct, aadt,
               segment_count, composite_score
        FROM "Year_2025".arterial_intersection_severity
        ORDER BY rank
    """
    return pl.read_database_uri(
        query=query, uri=cbi_database.database_uri(), engine="connectorx"
    )


def build_scatter_chart(df: pl.DataFrame) -> str:
    fig = go.Figure(
        data=go.Scatter(
            x=df["aadt"].to_list(),
            y=(1 - df["worst_peak_drop_ratio"]).to_list(),
            mode="markers+text",
            text=[f"#{r}" for r in df["rank"].to_list()],
            textposition="top center",
            marker=dict(
                size=[8 + (o / 100 * 20) for o in df["occurrence_pct"].to_list()],
                color=df["occurrence_pct"].to_list(),
                colorscale=[[0, LIGHT_SHADE], [1, AMBER]],
                showscale=True,
                colorbar=dict(title="Occurrence %"),
                line=dict(width=1.5, color=NAVY),
            ),
            hovertext=[
                f"{row['arterial_group']} / {row['intersection']}<br>"
                f"AADT: {row['aadt']:,}<br>"
                f"Speed drop: {(1 - row['worst_peak_drop_ratio']) * 100:.1f}%<br>"
                f"Occurrence: {row['occurrence_pct']:.1f}%"
                for row in df.iter_rows(named=True)
            ],
            hoverinfo="text",
        )
    )

    fig.update_layout(
        title="Top 20 Arterial Intersections — AADT vs. Peak-Hour Speed Drop",
        xaxis_title="AADT (traffic volume)",
        yaxis_title="Peak-hour speed drop below free flow",
        yaxis_tickformat=".0%",
        height=560,
        plot_bgcolor="#F7F9FC",
        paper_bgcolor="white",
        font=dict(family="Georgia, serif", color="#333333"),
        title_font=dict(color=NAVY, size=18),
    )

    return pio.to_html(fig, include_plotlyjs="cdn", full_html=False)


def build_table_html(df: pl.DataFrame) -> str:
    rows_html = ""
    for row in df.iter_rows(named=True):
        rows_html += f"""
        <tr>
            <td>{row['rank']}</td>
            <td>{row['arterial_group']}</td>
            <td>{row['intersection']}</td>
            <td>{row['county'] or ''}</td>
            <td>{row['segment_count']}</td>
            <td>{row['aadt']:,}</td>
            <td>{(1 - row['worst_peak_drop_ratio']) * 100:.1f}%</td>
            <td>{row['occurrence_pct']:.1f}%</td>
            <td>{row['composite_score']:.2f}</td>
        </tr>"""

    return f"""
    <table class="data">
        <thead>
            <tr>
                <th>Rank</th><th>Arterial</th><th>Intersection</th><th>County</th>
                <th>Segments</th><th>AADT</th><th>Peak Speed Drop</th>
                <th>Occurrence</th><th>Composite Score</th>
            </tr>
        </thead>
        <tbody>{rows_html}
        </tbody>
    </table>
    """


def build_kpi_cards(df: pl.DataFrame) -> str:
    top = df.row(0, named=True)
    avg_drop = (1 - df["worst_peak_drop_ratio"]).mean() * 100
    avg_occurrence = df["occurrence_pct"].mean()

    def card(label: str, value: str, sub: str = "") -> str:
        sub_html = f'<div class="sub">{sub}</div>' if sub else ""
        return f"""
        <div class="kpi-card">
            <div class="label">{label}</div>
            <div class="value">{value}</div>
            {sub_html}
        </div>"""

    return f"""
    <div class="kpi-row">
        {card("Worst Intersection", f"{top['arterial_group']}", top['intersection'])}
        {card("Its Peak Speed Drop", f"{(1 - top['worst_peak_drop_ratio']) * 100:.1f}%", f"AADT {top['aadt']:,}")}
        {card("Avg Speed Drop (Top 20)", f"{avg_drop:.1f}%")}
        {card("Avg Occurrence (Top 20)", f"{avg_occurrence:.1f}%")}
    </div>
    """


def generate_report(connection: psycopg.Connection, output_path: Path = OUTPUT_PATH) -> Path:
    df = load_results(connection)

    if df.is_empty():
        raise RuntimeError(
            "arterial_intersection_severity is empty — run "
            "cbi_arterial_intersection_severity.py first."
        )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Top 20 Arterial Intersections — Congestion Severity</title>
<style>
    body {{ font-family: Georgia, serif; background: #F7F9FC; color: #333; margin: 0; padding: 0; }}
    .masthead {{ background: {NAVY}; color: white; padding: 24px 32px; }}
    .masthead h1 {{ margin: 0; font-size: 24px; }}
    .masthead .sub {{ font-size: 13px; color: #C9D6E8; font-style: italic; margin-top: 4px; }}
    .content {{ max-width: 1100px; margin: 0 auto; padding: 24px 32px; }}
    .kpi-row {{ display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 24px; }}
    .kpi-card {{ flex: 1; min-width: 200px; background: white; border: 1px solid #DCE3EC;
                 border-left: 4px solid {AMBER}; border-radius: 4px; padding: 14px 18px; }}
    .kpi-card .label {{ font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; }}
    .kpi-card .value {{ font-size: 22px; font-weight: bold; color: {NAVY}; margin-top: 4px; }}
    .kpi-card .sub {{ font-size: 12px; color: #888; margin-top: 2px; }}
    table.data {{ width: 100%; border-collapse: collapse; background: white; margin-top: 16px; }}
    table.data th {{ background: {NAVY}; color: white; padding: 10px 12px; text-align: left; font-size: 13px; }}
    table.data td {{ padding: 8px 12px; border-bottom: 1px solid #EEE; font-size: 13px; }}
    table.data tr:nth-child(even) {{ background: #F2F6FA; }}
    .methodology {{ background: white; border: 1px solid #DCE3EC; border-radius: 4px;
                     padding: 16px 20px; margin-top: 24px; font-size: 13px; color: #555; }}
    .methodology h3 {{ color: {ACCENT}; margin-top: 0; }}
    footer {{ text-align: center; font-size: 11px; color: #999; padding: 24px; font-style: italic; }}
</style>
</head>
<body>

<div class="masthead">
    <h1>Top 20 Arterial Intersections — Congestion Severity</h1>
    <div class="sub">Generated {date.today().isoformat()} \u00b7 CBI Multi-Corridor Pipeline \u2014 Arterial Severity Extension</div>
</div>

<div class="content">
    {build_kpi_cards(df)}
    {build_scatter_chart(df)}
    {build_table_html(df)}

    <div class="methodology">
        <h3>Methodology</h3>
        <p>Free-flow speed is the hour of day with the highest average speed
        across all Arterial-classified segments region-wide, applied to each
        segment's own observed speed at that hour as its individual
        baseline &mdash; not computed independently per segment, which would
        let a chronically congested segment define its own artificially low
        baseline. Peak-hour speed drop is each segment's worst (minimum)
        average speed during AM (7&ndash;9) or PM (16&ndash;18) peak hours,
        relative to that baseline. Fragmented multi-segment arterials
        (Buford Hwy, Roswell Rd, and others) are grouped under one named
        corridor before ranking. Final ranking uses K-means clustering on
        standardized [speed drop, occurrence, AADT] to isolate the
        worst-behaving group, then ranks within it.</p>
    </div>
</div>

<footer>
    CBI Multi-Corridor Pipeline &mdash; Arterial Intersection Severity (standalone page, pending integration into the main regional dashboard)
</footer>

</body>
</html>
"""

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    return output_path


if __name__ == "__main__":
    with psycopg.connect(**cbi_database.connection_kwargs()) as conn:
        path = generate_report(conn)
        print(f"Report written to: {path}")
